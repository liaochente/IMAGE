Fugue Icons

(C) 2012 Yusuke Kamiyamane. All rights reserved.
These icons are licensed under a Creative Commons
Attribution 3.0 License.
<http://creativecommons.org/licenses/by/3.0/>

If you can't or don't want to provide attribution, please
purchase a royalty-free license.
<http://p.yusukekamiyamane.com/>

I'm unavailable for custom icon design work. But your
suggestions are always welcome!
<mailto:p@yusukekamiyamane.com>

------------------------------------------------------------

- geotag

  (C) Geotag Icon Project. All rights reserved.
  <http://www.geotagicons.com/>

  Geotag icon is licensed under a Creative Commons
  Attribution-Share Alike 3.0 License or LGPL.
  <http://creativecommons.org/licenses/by-sa/3.0/>
  <http://opensource.org/licenses/lgpl-license.php>

- language

  (C) Language Icon Project. All rights reserved.
  <http://www.languageicon.org/>

  Language icon is licensed under a Creative Commons
  Attribution-Share Alike 3.0 License.
  <http://creativecommons.org/licenses/by-sa/3.0/>

- open-share

  (C) Open Share Icon Project. All rights reserved.
  <http://www.openshareicons.com/>

  Open Share icon is licensed under a Creative Commons
  Attribution-Share Alike 3.0 License.
  <http://creativecommons.org/licenses/by-sa/3.0/>

- opml

  (C) OPML Icon Project. All rights reserved.
  <http://opmlicons.com/>

  OPML icon is licensed under a Creative Commons
  Attribution-Share Alike 2.5 License.
  <http://creativecommons.org/licenses/by-sa/2.5/>

- share

  (C) Share Icon Project. All rights reserved.
  <http://shareicons.com/>

  Share icon is licensed under a GPL or LGPL or BSD or
  Creative Commons Attribution 2.5 License.
  <http://opensource.org/licenses/gpl-license.php>
  <http://opensource.org/licenses/lgpl-license.php>
  <http://opensource.org/licenses/bsd-license.php>
  <http://creativecommons.org/licenses/by/2.5/>

- xfn

  (C) Wolfgang Bartelme. All rights reserved.
  <http://www.bartelme.at/>

  XFN icon is licensed under a Creative Commons
  Attribution-Share Alike 2.5 License.
  <http://creativecommons.org/licenses/by-sa/2.5/>